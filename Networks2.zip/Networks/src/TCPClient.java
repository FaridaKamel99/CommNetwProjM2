import java.io.*; 
	import java.net.*; 
public class TCPClient {
	 public static void main(String argv[]) throws Exception 
	    { 
	        String sentence; 
	        String modifiedSentence; 

	        BufferedReader inFromUser = 
	          new BufferedReader(new InputStreamReader(System.in)); 
	        sentence = inFromUser.readLine();
	        if(sentence.equals("connect")) {
	        	
	        	
	        Socket clientSocket = new Socket("127.0.0.1", 2020); 
	        DataOutputStream outToServer = 
	  	          new DataOutputStream(clientSocket.getOutputStream());
	        outToServer.writeBytes(sentence + '\n');
	        
	        while(true) {
	        	inFromUser = 
	      	          new BufferedReader(new InputStreamReader(System.in)); 
	        	sentence = inFromUser.readLine();
	         
	        BufferedReader inFromServer = 
	                new BufferedReader(new
	                InputStreamReader(clientSocket.getInputStream())); 
	        outToServer.writeBytes(sentence + '\n');
	               
	              if(sentence.equals("bye")) {
	            	  
	            	  clientSocket.close();
	            	  break;
	              }

	              
	              else {
	              modifiedSentence = inFromServer.readLine(); 

	              System.out.println("FROM SERVER: " + modifiedSentence); 

	               }
	        }}
	        else {

	        }
	 
}
}
