import java.io.*; 
import java.net.*; 

public class TCPServer {

	  public static void main(String argv[]) throws Exception 
	    { 
	      String clientSentence; 
	      String capitalizedSentence; 

	      ServerSocket welcomeSocket = new ServerSocket(2020); 
	  
	      while(true) { 
	    	  
	            Socket connectionSocket = welcomeSocket.accept(); 

	           BufferedReader inFromClient = 
	              new BufferedReader(new
	              InputStreamReader(connectionSocket.getInputStream())); 
	           clientSentence = inFromClient.readLine();
		        System.out.println("Client Says: "+clientSentence);

	           if(clientSentence.equals("connect")) {
	        	   System.out.println("Client Connected");
	        	   while(true) {
	    	           clientSentence = inFromClient.readLine();
	    	           
	        		   if(!clientSentence.equals("bye")) {
	        			   
	        		   
	        		   
	       		        System.out.println("Client Says: "+clientSentence);
	        	   
	           
	           DataOutputStream  outToClient = 
	                   new DataOutputStream(connectionSocket.getOutputStream()); 

	                 
	     	        

	                 capitalizedSentence = clientSentence.toUpperCase() + '\n'; 

	                 outToClient.writeBytes(capitalizedSentence); 
	              }
	        		   else{
	        			   connectionSocket.close();
	        			   System.out.println("Connection Closed");
	        			   break;
	        		   }
	        			   }}
	        		   }
	          } 
	      


}
	    
